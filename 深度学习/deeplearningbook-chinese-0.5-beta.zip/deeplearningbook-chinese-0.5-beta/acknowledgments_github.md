#致谢


2016年12月8日
------------
 - @tttwwy ==> 链接问题
 - @tankeco ==> Chapter12 语句不通
 - @fairmiracle ==> Chapter2 公式问题，Chapter4 邻域==>领域
 - @GageGao ==> Chapter5 Iris在里面被翻译成虹膜，应该翻译成鸢尾花
 - @huangpingchun ==> Chapter1 "多么"误打为"多少"了, Chapter5大量建议，详见[issue](https://github.com/exacity/deeplearningbook-chinese/issues/10)
 - @MaHongP ==> Chapter6 纠正词语, p139 ，"仿射"，"及其" 
 - @acgtyrant ==> 翻译者改进英式中文
 - @yanhuibin315 ==> gitbook
 - @Buttonwood ==> Chapter2 dot product
 - @titicacafz ==> Chapter2 dot product
 - @weijy026a ==> Chapter1 Inventors翻译建议
 - @RuiZhang1993 ==> Chapter2 公式有误
 - @zymiboxpay ==> Chapter2 等号消失
 - @xingkongliang ==> Chapter2 公式有误
 - @oisc ==>  Chapter2 公式2.83 2.84有误 是arg max



2016年12月9日
------------
 - @fairmiracle ==> Chapter4 公式，语句，详见[issue](https://github.com/exacity/deeplearningbook-chinese/issues/3#issuecomment-265854595).
 - @huangpingchun ==> Chapter1 邻域==>领域
 - @tielei ==> Chapter9 equivariance
 - @yuduowu ==> contact issue
 - @minoriwww ==> Chapter2 "排布"==>"排列"
 - @khty2000 ==> Chapter2 "X{-S}"问题，矩阵横列错误
 - @Qingmu ==> 用WinEdit打开文件问题
 - @tielei ==> Chapter9 公式的index问题



2016年12月10日
-------------
 - @fairmiracle ==> Chapter5 "\Vy"==>"\Vx"；多余括号；in action，more frequently，more formally 提议校对，imputation 翻译建议
 - @huangpingchun ==> Chapter5 not completely formal or distinct concepts, VC维，imputation of missing data 翻译建议
 - @tielei ==> Chapter9 "full convolution"；翻译建议；"tiling range"



2016年12月12日
-------------
 - @fairmiracle ==> Chapter6 公式错误
 - @huangpingchun ==> Chapter7 "模型平均"重复



2016年12月13日
-------------
 - @huangpingchun ==> inference的统一翻译 
 - @HC-2016 ==> Chapter6 单位阵还是对角阵问题，详见[issue](https://github.com/exacity/deeplearningbook-chinese/issues/19#issuecomment-266683442).
 - @xiaomingabc ==> Chapter1 病句问题



2016年12月14日
--------------
 - @fairmiracle ==> Chapter7 \norm 括号打错
 - @bengordai ==> Chapter1 区分出合法邮件与垃圾邮件



2016年12月15日
--------------
 - @huangpingchun ==> Chapter5 "supervised"误译为"无监督, Chapter7 模块翻译
 - @Bojian ==> Chapter5 "supervised"误译为"无监督"，"三维空间中球状流形"翻译建议



2016年12月16日
-------------
 - @huangpingchun ==> "infinite" 翻译统一化
 - @JoyFYan ==> 错字"植"
 - @fairmiracle ==> 修正翻译"based on making small local moves"

2016年12月18日
--------------
 - @bengordai ==> Chapter6, "until"和"address"的翻译；双引号


2016年12月20日
-------------
 - @fairmiracle ==> Chapter8, f 


2016年12月20日
-------------
 - @zdx3578 ==> 错别字"如果"改成"如何"


2016年12月21日
-------------
 - @huangpingchun ==> Chapter8, vanishing Long-Term Dependencies翻译


2016年12月22日
-------------
 - @PassStory ==> Chapter2, m -> n
 - @imwebson ==> Chapter2, m -> n
 - @HC-2016 ==> Chapter6, 语句问题；错别字"相应"改成"响应"
 - @Elvinczp ==> Chapter6, 错别字"网路"改成"网络"
 - @imwebson ==> Chapter6, "winner-take-all"翻译成"赢者通吃"


2016年12月23日
-------------
 - @zdx3578 ==> Chapter5, one-hot
 - @wlbksy  ==> Chapter14, 编译问题
 - @zdx3578 ==> Chapter6, 错别字"有"改成"由", "难么"改成"那么""


2016年12月25日
---------------
 - @roachsinai ==> Chapter10, 第315行公式错误
 - @minoriwww ==> Chapter6, "loosely"翻译为"或多或少地"；"funciton"翻译为"功能"


2016年12月26日
---------------
 - @zdx3578 ==> Chapter8, 280页翻译


2016年12月27日
---------------
 - @huangpingchun ==> Chapter8, 8.7.4节翻译


2016年12月29日
---------------
 - @zdx3578 ==> Chapter11, 11.4节翻译


2016年12月31日
---------------
 - @endymecy ==> Chapter10, 公式20错误


2017年1月3日
---------------
 - @endymecy ==> Chapter14, 语句问题


2017年1月5日
---------------
 - @tonyzeng2016 ==> Chapter8, 8.1.2最后一段翻译建议
 - @zdx3578 ==> Chapter18, "intractable"翻译建议


2017年1月7日
---------------
 - @zdx3578 ==> Chapter20, 公式错误，少子图
 - name:YUE-DaJiong ==> Chapter20, discriminator network


2017年1月11日
---------------
 - @HeimingX ==> Chapter5，5.9节翻译


2017年2月4日
---------------
 - @zhangyafeikimi ==> Chapter8，"树木"=>"数目"


2017年2月7日
---------------
 - @germany-zhu  ==> Chapter1, 语音术语
 - @kangqf ==> Chapter8, loccal_minima 笔误
